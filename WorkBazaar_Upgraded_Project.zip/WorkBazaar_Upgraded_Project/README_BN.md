# WorkBazaar — Upgraded project

এই সংস্করণটি আপনার আপলোড করা `WorkBazaar Website (1).html`-এর উপর তৈরি। মূল সবুজ/অ্যাম্বার/কোরাল ডিজাইন, Explore/Profile/Inbox/Chat নেভিগেশন, Firebase connect, Google sign-in, Gig cards ও তিনটি package model রাখা হয়েছে। নতুন অংশগুলো মূল HTML-এ যোগ করা `upgrade.js` layer দিয়ে কাজ করে।

## কী যোগ হয়েছে

- Seller dashboard, wallet balance, lifetime earnings, pending payout ও payout history
- Buyer/Seller order status: payment submitted → confirmed → in progress → delivered → revision requested → completed; cancellation ও dispute
- Seller Gig edit/delete এবং Gig cover image upload
- Private order delivery upload/download
- Admin dashboard: pending manual payments, orders, user count ও payout review
- Admin-set USD→BDT exchange rate; order-এ rate/আনুমানিক BDT পরিমাণ snapshot করে রাখা
- Server-side order amount, 5% platform fee / 95% Seller credit, duplicate TrxID guard
- In-app notifications for order status, messages and payouts
- Firestore ও Storage security rules; admin permission Firebase Custom Claims দিয়ে নিয়ন্ত্রিত

## গুরুত্বপূর্ণ সীমাবদ্ধতা

1. এটি একটি **কোড প্যাকেজ**, আপনার Firebase project-এ deploy করা বা live payment পরীক্ষা করা হয়নি।
2. bKash/Nagad payment এখানে **manual**। Buyer TrxID জমা দেয়; Admin নিজের merchant statement/app-এ টাকা যাচাই করে Admin Dashboard-এ Confirm করে। কোনো bKash/Nagad merchant API বা automatic payment gateway credentials এই প্রকল্পে দেওয়া নেই।
3. Admin dashboard দেখতে `admin=true` Firebase Custom Claim লাগবে। শুধু UI-তে Admin লেখা বা email মিললেই Admin হওয়া যাবে না।
4. Cloud Functions ও Firebase Storage চালাতে Firebase project-এ **Blaze billing plan** লাগবে। Blaze pay-as-you-go; budget alert সেট করুন। Storage-এ no-cost allowance থাকতে পারে, কিন্তু Blaze billing link দরকার।
5. Cloud Functions runtime Node.js 22 সেট করা আছে।
6. বাস্তব Firestore/Storage region নির্বাচন আপনার বিদ্যমান Firebase database/bucket কোথায় আছে তার সঙ্গে মিলিয়ে নেবেন; বর্তমানে functions code-এ `asia-south1` (Mumbai) ব্যবহৃত হয়েছে। আপনার Firestore বা Storage অন্য অঞ্চলে হলে deploy-এর আগে `functions/index.js` ও `public/upgrade.js`-এর region একসঙ্গে পরিবর্তন করুন।
7. পুরোনো HTML-এর আগের `placed` status-এ থাকা orders স্বয়ংক্রিয়ভাবে migrate করা হয়নি। Deploy করার আগে পুরোনো order records পরীক্ষা করুন। পুরোনো completed order-কে নতুন wallet-এ স্বয়ংক্রিয় credit করা হয় না—যাতে double payout না হয়।

## Deploy করার আগে

### 1) Firebase project তৈরি / নির্বাচন

Firebase Console-এ আপনার Project খুলুন। Web App-এর Firebase config সংগ্রহ করুন। Authentication-এ Google provider চালু করুন এবং Hosting domain/আপনার custom domain Authorized domains-এ যোগ করুন। Firestore Database ও Storage চালু করুন।

### 2) Project ফাইল বসান

এই ZIP extract করুন। `firebase.json`, `firestore.rules`, `storage.rules`, `firestore.indexes.json` এবং `functions/` একই project root-এ থাকবে। Hosting-এর জন্য `public/index.html` ব্যবহার হবে।

### 3) Firebase CLI ও deployment

```bash
npm install -g firebase-tools
firebase login
firebase use --add
cd functions
npm install
cd ..
firebase deploy --only firestore:rules,firestore:indexes,storage,functions,hosting
```

Deploy চলার সময় Firebase CLI যদি billing/API enable করতে বলে, Console থেকে প্রয়োজনীয় সেটআপ সম্পন্ন করুন। Firestore database ও Storage bucket region আগে নিশ্চিত করুন। Delivery file-এর authenticated browser download-এর জন্য bucket CORS config-ও সেট করতে হতে পারে; `cors.json` template-এ origin আপনার Hosting domain দিয়ে সীমিত করুন। তারপর bucket-এ CORS প্রয়োগ করুন (উদাহরণ): `gcloud storage buckets update gs://YOUR_STORAGE_BUCKET --cors-file=cors.json`। Firebase web config-এর `storageBucket` থেকে সঠিক bucket নাম নিন।

### 4) Web app config যুক্ত করুন

Hosting URL খুলুন → Profile → Firebase Setup। Firebase Console-এর `firebaseConfig` block paste করে Connect চাপুন। তারপর Google দিয়ে Sign in করুন। Android browser-এ sign-in redirect flow ব্যবহার হবে।

### 5) Admin account নিরাপদে চালু করুন

প্রথমে Admin হতে যাওয়া user-কে সাইটে একবার Google দিয়ে Sign in করতে হবে। Firebase Authentication → Users থেকে তার UID কপি করুন। তারপর local machine-এ Google Cloud CLI/ADC authentication করে root directory-তে:

```bash
npm install
```

Linux/macOS:

```bash
export FIREBASE_PROJECT_ID="YOUR_FIREBASE_PROJECT_ID"
export ADMIN_UID="THE_USER_UID"
gcloud auth application-default login --project "$FIREBASE_PROJECT_ID"
node scripts/set-admin.js
```

PowerShell:

```powershell
$env:FIREBASE_PROJECT_ID="YOUR_FIREBASE_PROJECT_ID"
$env:ADMIN_UID="THE_USER_UID"
gcloud auth application-default login --project $env:FIREBASE_PROJECT_ID
node scripts/set-admin.js
```

Admin user-কে Sign out করে আবার Sign in করতে হবে, যাতে নতুন Custom Claim token-এ আসে। `scripts/set-admin.js` কখনো browser-এ চালাবেন না; service account/ADC credentials কাউকে দেবেন না।

### 6) Payment পরিচালনা

Admin Dashboard-এ bKash/Nagad receiving number এবং নিজের নির্ধারিত ১ USD = কত BDT rate বসিয়ে Save করতে হবে। Buyer order form-এ নির্বাচিত প্যাকেজের আনুমানিক BDT পরিমাণ দেখবে; server rate ও USD amount order-এ সংরক্ষণ করবে। Buyer bKash/Nagad, sender number ও TrxID জমা দেয়। Admin নিজের payment account/statement-এ সঠিক BDT amount ও TrxID মিলিয়ে Admin Dashboard-এ “পেমেন্ট যাচাই / Confirm” চাপবে। Seller কাজ শুরু করবে। Buyer delivery Complete করলে Seller-এর Wallet-এ server-side 95% যোগ হবে। Seller payout request দিলে request-এ ব্যবহৃত exchange rate অনুযায়ী আনুমানিক BDT amount সংরক্ষিত হবে। Admin বাইরে থেকে bKash/Nagad-এ টাকা পাঠানোর পর payout request-এ Paid চাপবে।

## Firebase collections

- `gigs` — public service listings; owner controls edits
- `orders` — Buyer/Seller orders; client write বন্ধ, Cloud Functions handles state transitions
- `paymentTransactions` — unique payment reference hashes; client access বন্ধ
- `users` — user payout details
- `wallets`, `ledger` — server-managed balance/earning records
- `payouts` — Seller payout requests; server-managed
- `notifications` — per-user in-app notifications
- `messages`, `support` — order chat and admin support
- `adminUsers` — trusted admin UID register; actual access uses Firebase Custom Claims

## Test checklist

- [ ] Google sign-in on desktop and Android
- [ ] A signed-in Seller creates a Firebase-backed Gig and uploads a cover image
- [ ] Admin sets bKash/Nagad receiving numbers and a valid USD→BDT rate
- [ ] Buyer sees the estimated BDT amount for the selected USD package
- [ ] Buyer submits a unique bKash/Nagad TrxID; duplicate TrxID must fail
- [ ] Non-admin user cannot read other users' orders or open Admin Dashboard
- [ ] Admin verifies payment; Seller starts work and submits delivery
- [ ] Buyer requests revision, receives a new delivery, then completes order
- [ ] Seller wallet receives exactly 95%; platform fee is 5%
- [ ] Seller submits payout; Admin marks Paid or Rejects; wallet totals reconcile
- [ ] Buyer/Seller receive notifications and only order participants can download delivery files
- [ ] Firebase Rules Playground / Emulator tests confirm unauthenticated and cross-user access is denied

**এই project-এ live deployment, Firebase Rules Emulator test, real-device acceptance test, payment statement verification বা real bKash/Nagad transfer করা হয়নি। সাইট প্রকাশের আগে উপরোক্ত checklist চালাতে হবে।**
